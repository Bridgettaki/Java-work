package java.take.home.test;

public class JavaTakeHomeTest {

    
    public static void main(String[] args) {
      
         registration reg = new registration();
    }
    
}
