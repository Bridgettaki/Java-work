/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java.take.home.test;

public class storedUser {


    //global variables
    public String firstName;
    public String lastName;
    public String userName;
    private String password;

    //retrieves the firstName from the global variable userName (W3school, 2023)
    public String getFirstName() {
        return firstName;
    }

    //sets the firstName to the global variable userName (W3school, 2023)
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    //retrieves the lastName from the global variable userName (W3school, 2023)
    public String getLastName() {
        return lastName;
    }

    //sets the lastName to the global variable userName (W3school, 2023)
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    //retrieves the username from the global variable userName (W3school, 2023)
    public String getUserName() {
        return userName;
    }

    //sets the username to the global variable userName (W3school, 2023)
    public void setUserName(String userName) {
        this.userName = userName;
    }

    //retrieves the password from the global variable password (W3school, 2023)
    public String getPassword() {
        return password;
    }

    //sets the password to the global variable password (W3school, 2023)
    public void setPassword(String password) {
        this.password = password;
    }


}

